# Speedometer

# IDE: Android Studio

# Language : JAVA

# Android Application

-------------------------------------------------------------------------

A nice Speedometer with graphical view implemented in Android Studio 3.0

After you open the GPS from the dropdown menu you can select some places and you can find the distance you are from them in Km
in the second form you can see with graphical view your speed in Km/h

------------------------------------------------------------------------
